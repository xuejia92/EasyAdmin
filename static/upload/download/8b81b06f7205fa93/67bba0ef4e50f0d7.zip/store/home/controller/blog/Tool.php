<?php
namespace app\home\controller\blog;

use think\Db;

class Tool extends Base {
    public function websocket(){
        return $this->fetch('blog/tool/websocket',[
        ]);
    }
}