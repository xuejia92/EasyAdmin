<?php
namespace app\home\controller\blog;

use think\Db;

class Article extends Base {
    public function blog(){
        $id = $this->request->get('id','');
        if($id=='' || !is_numeric($id)){
            $this->redirect('/home/blog');
        }
        $article=Db::name('BlogArticle')->where(['isfabu'=>1,'id'=>$id])->find();

        if(!$article){
            $this->redirect('/home/blog');
        }else{
            $article['categroyname']=Db::name('BlogCategory')->where(['id'=>$article['category']])->value('name');
        }
        $tagslist=Db::name('BlogArticleLabel')->where(['article_id'=>$id])->select();
        if($tagslist){
            $this->tagslist=$tagslist;
        }
        Db::name('BlogArticle')->where(['id'=>$id])->setInc('view_count');
        //上一篇
        $front=Db::name('BlogArticle')->where(" id<".$id)->where(['isfabu'=>1])->order('id desc')->limit('1')->find();
        $after=Db::name('BlogArticle')->where(" id>".$id)->where(['isfabu'=>1])->order('id asc')->limit('1')->find();

        //评论
        $comment=Db::name('BlogCommit')->where(['articleid'=>$id,'isshow'=>1,'parentid'=>0])->order('addtime desc')->select();

        $countcomment=Db::name('BlogCommit')->where(['isshow'=>1,'articleid'=>$id])->count();
        $article_front=$front;
        $article_after=$after;
        $zannum=Db::name('BlogArticleZan')->where(['articleid'=>$id])->count();
        $taglist=Db::name("BlogArticleLabel")->where(['article_id'=>$id])->select();
        return $this->fetch('/blog/article/blog',[
            'article'=>$article,
            'countcomment'=>$countcomment,
            'article_front'=>$article_front,
            'article_after'=>$article_after,
            'zannum'=>$zannum,
            'comment'=>$comment,
            'taglist'=>$taglist,
            'isLogin'=>true
        ]);
    }

    public function addCommit(){
        $da=I('');
        $data['articleid']=$da['articleid'];
        $data['content']=trim($da['content']);
        if($data['articleid'] && $data['content']){
            $data['uid']=$_SESSION['uid'];
            $data['addtime']=time();
            $data['isshow']=1;
            $data['parentid']=$da['parentid'];
            if(M('commit')->add($data)){
                exit(json_encode(['state'=>1,'msg'=>'提交成功']));
            }else{
                exit(json_encode(['state'=>0,'msg'=>'提交失败']));
            }
        }else{
            exit(json_encode(['state'=>0,'msg'=>'提交失败']));
        }
    }

    public function addZan(){
        $da=I('');
        $data['articleid']=$da['articleid'];
        $data['clientip']=get_client_ip();
        if($data['articleid']){
            if($zan=M('article_zan')->where($data)->find()){
                exit(json_encode(['state'=>0,'msg'=>'当前已经赞过啦！']));
            }else{
                $res=M('article_zan')->add($data);
                if($res){

                    exit(json_encode(['state'=>1,'msg'=>'已赞！']));
                }else{
                    exit(json_encode(['state'=>0,'msg'=>'提交失败！']));
                }
            }
        }else{
            exit(json_encode(['state'=>0,'msg'=>'提交失败']));
        }
    }
}