<?php
// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\port\model;

use think\Model;

/**
 * 模型基类
 * Class Base
 * @package app\model
 */
class Base extends Model {

}