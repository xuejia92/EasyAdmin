<?php
// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\port\model;

/**
 * app id&secret模型
 * Class ApiApp
 * @package app\model
 */
class ApiApp extends Base
{

}
