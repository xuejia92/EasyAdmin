<?php
// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\api\model;

/**
 * app id&secret模型
 * Class ApiApp
 * @package app\model
 */
class ApiApp extends Base
{

}
