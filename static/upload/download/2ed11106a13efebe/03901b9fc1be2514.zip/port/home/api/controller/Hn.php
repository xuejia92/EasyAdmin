<?php

// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\api\controller;

use controller\BasicApi;
use think\facade\App;

/**
 * API index类
 * Class Index
 * @package app\api\controller
 */
class Hn extends BasicApi
{
    /**
     * @return \think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function index()
    {
        $this->debug([
            'ThinkPHPVersion' => App::version(),
            'PHPVersion' => PHP_VERSION
        ]);

        return $this->buildSuccess([
            'Product' => sysconf('site_name'),
            'Version' => sysconf('app_version'),
            'Company' => sysconf('site_copy'),
            'ToYou' => "I'm glad to meet you（终于等到你！1）"
        ]);
    }
}
