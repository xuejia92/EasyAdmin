<?php
// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\api\model;

/**
 * 接口字段规则模型
 * Class ApiFields
 * @package app\model
 */
class ApiFields extends Base {

}