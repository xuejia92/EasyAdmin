<?php

// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\api\controller;

use controller\BasicApi;

/**
 * 通用测试API接口类
 * Class Debug
 * @package app\api\controller
 */
class Debug extends BasicApi
{

}