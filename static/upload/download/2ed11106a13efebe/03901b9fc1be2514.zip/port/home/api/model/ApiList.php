<?php
// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\api\model;

/**
 * 接口列表模型
 * Class ApiList
 * @package app\model
 */
class ApiList extends Base {

}