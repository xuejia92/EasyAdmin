<?php
// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\api\model;

use think\Model;

/**
 * 模型基类
 * Class Base
 * @package app\model
 */
class Base extends Model {

}