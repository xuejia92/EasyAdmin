<?php
// +----------------------------------------------------------------------
// | ThinkApiAdmin
// +----------------------------------------------------------------------

namespace app\api\model;

/**
 * 接口组模型
 * Class ApiGroup
 * @package app\model
 */
class ApiGroup extends Base {

}