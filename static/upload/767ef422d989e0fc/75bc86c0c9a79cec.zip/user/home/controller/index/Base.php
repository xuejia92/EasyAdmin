<?php
namespace app\home\controller\index;

use controller\BasicFront;
use think\facade\Env;

class Base extends BasicFront
{
    public $title='EasyAdmin - 基于ThinkPHP5的极速后台开发框架';

    public function fetch($template = '', $vars = [], $config = []) {
        $appRoot = app('request')->root();
        $uriRoot = rtrim(preg_match('/\.php$/', $appRoot) ? dirname($appRoot) : $appRoot, '\\/');
        $this->view->engine([
            'view_path'=>Env::get('app_path').'home\view\\',
            'tpl_replace_string'=>[
                '__STATIC__' => $uriRoot . "/static",
            ]
        ]);
        return parent::fetch($template, $vars, $config);
    }
}